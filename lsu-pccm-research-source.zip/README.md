# CTS Research Hub

A first-release research resource website for LSU Health New Orleans faculty and fellows.

Intended custom domain: **lsupccmresearch.org** (purchased by the owner on November 8, 2026). This does not imply DNS or hosting is connected.

## Run

For a single-file review copy, open `preview/CTS_Research_Hub_Preview.html`. It includes the current PCCM faculty and fellows banner and an embedded Word directory download.

Open `dist/index.html` directly in a browser; there are no dependencies or build requirements for the delivered site. Search, filters, hash navigation, local resource pages, and the DOCX download work without a backend.

For HTTP preview, serve the `dist/` directory with a static server.

## Contents

- 40 research databases across 17 topics, retaining the current Word directory.
- 13 official LSU resource links with brief descriptions and access notes.
- IRB, protocol and consent templates, Kuali, training, REDCap, onboarding, library and research support.
- Four conference series/source pages. Pulmonary and Critical Care research recurrence is owner-provided: **second and fourth Wednesdays at noon, America/Chicago**. The prior schedule upload will supply speakers/topics; no dates or speakers were invented.
- Responsive purple/gold LSU Health visual direction, keyboard navigation, and mobile menu.

## Source updates

`build-data.js` creates `dist/app-data.js` from the checked-in `data/database-inventory.json` and institutional resources. The current Word document is included in `dist/assets/`. Both the source and delivered `dist/` work independently of the originating task.

Run `node verify.cjs` from this directory for focused integrity, filtering, route rendering, link-structure, download, and schedule checks. The tests compare the supplied inventory and exact recorded document hash. `build-preview.cjs` produces a self-contained HTML review copy in the parent directory.

## Deployment

Site identity is recorded in `.openai/hosting.json`. The Sites source helper configured the local Git repository but could not reach its remote host (`Could not resolve host: git.chatgpt-team.site`). A successful source push and deployment are not yet verified. Do not fabricate a deployed commit or change the Site identity to retry.

The current execution directory is outside iCloud but temporary. The intended canonical documentation home is `/Users/dwelsh/Projects/Coding/Websites/lsu-health-cts-research-hub`; write access there is not available in this session. The preferred future active checkout is outside iCloud, normally `/Users/dwelsh/Developer/OpenAI/lsu-health-cts-research-hub`. Canonical promotion remains separate from hosting deployment.

## Project records

`docs/planning/` preserves the user requirements, rapid-launch direction, website brief, and CTS Essentials design review. These are the initial planning records; `docs/VERIFICATION.md` records the built release and remaining hosting limitations.
